bash secretsmanager_setup.sh
